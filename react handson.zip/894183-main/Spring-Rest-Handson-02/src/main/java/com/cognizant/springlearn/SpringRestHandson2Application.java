package com.cognizant.springlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestHandson2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestHandson2Application.class, args);
	}

}
