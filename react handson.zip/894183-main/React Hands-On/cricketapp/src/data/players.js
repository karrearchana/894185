import React from 'react';
const PLAYERS =[
{
    id:1,
    name:'Mr.Jack',
    score: 50,
},
{
    id:2,
    name:'Mr.Micheal',
    score: 70
},
{
    id:3,
    name:'Mr.John',
    score: 40
},
{
    id:4,
    name:'Mr.Ann',
    score: 61
},
{
    id:5,
    name:'Mr.Elisabeth',
    score: 61
},
{
    id:6,
    name:'Mr.sachin',
    score: 95
},
{
    id:7,
    name:'Mr.Dhoni',
    score: 100
},
{
    id:8,
    name:'Mr.virat',
    score: 84
},
{
    id:9,
    name:'Mr.Jadeja',
    score: 64
},
{
    id:10,
    name:'Mr.Raina',
    score: 75
},
{
    id:11,
    name:'Mr.Rohit',
    score: 80
}

];
export default PLAYERS;