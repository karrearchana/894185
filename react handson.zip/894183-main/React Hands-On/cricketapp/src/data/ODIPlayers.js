import React from 'react';
const ODIPLAYERS =[
{
    id:1,
    name:'Sachin',
    pos:'First'
    
},
{
    id:2,
    name:'Dhoni',
    pos:'Second'
    
},
{
    id:3,
    name:'Virat',
    pos:'Third'
    
},
{
    id:4,
    name:'Rohit',
    pos:'Fourth'
    
},
{
    id:5,
    name:'Yuvaraj',
    pos:'Fifth'
    
},
{
    id:6,
    name:'Raina',
    pos:'Sixth'
    
}
];
export default ODIPLAYERS;