import logo from './logo.svg';
import './App.css';
import Office from './office';

function App() {
  return (
    <div className="App">
       <Office/>
    </div>
  );
}

export default App;
