import Show from './Show';

function App() {
  return (
    <div className="App">
      <Show/>
    </div>
  );
}

export default App;
