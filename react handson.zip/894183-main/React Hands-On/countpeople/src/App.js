import React, { Component } from 'react';
import CountPeople from './CountPeople';
import './index.css';
class App extends Component {

  
  render() {
    return (
      <div>
        <CountPeople />
      </div>
    )
  }
}
export default App;